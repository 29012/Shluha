import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ArrowDownUp, r as RotateCcw, t as Undo2 } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CJCIgMKB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KINDS = /* @__PURE__ */ new Set([
	"k",
	"q",
	"r",
	"b",
	"n",
	"p"
]);
var START_ROWS = [
	"rnbqkbnr",
	"pppppppp",
	"8",
	"8",
	"8",
	"8",
	"PPPPPPPP",
	"RNBQKBNR"
];
function startingBoard() {
	const board = [];
	for (const row of START_ROWS) for (const ch of row) {
		if (ch === "8") {
			for (let i = 0; i < 8; i++) board.push(null);
			continue;
		}
		const color = ch === ch.toUpperCase() ? "w" : "b";
		const kind = ch.toLowerCase();
		board.push({
			id: `${color}${kind}-${board.length}`,
			color,
			kind
		});
	}
	return board;
}
function initialState() {
	return {
		board: startingBoard(),
		captured: [],
		last: null,
		history: [],
		selected: null,
		flipped: false
	};
}
function pushHistory(state) {
	const snap = {
		board: state.board,
		captured: state.captured,
		last: state.last
	};
	const next = state.history.concat(snap);
	return next.length > 80 ? next.slice(next.length - 80) : next;
}
function reducer(state, action) {
	switch (action.type) {
		case "select": return {
			...state,
			selected: action.index
		};
		case "move": {
			const { from, to } = action;
			const piece = state.board[from];
			if (!piece || from === to || to < 0 || to > 63) return state;
			const board = state.board.slice();
			const victim = board[to];
			board[from] = null;
			board[to] = piece;
			return {
				...state,
				board,
				captured: victim ? state.captured.concat(victim) : state.captured,
				last: [from, to],
				history: pushHistory(state),
				selected: null
			};
		}
		case "undo": {
			const prev = state.history[state.history.length - 1];
			if (!prev) return state;
			return {
				...state,
				board: prev.board,
				captured: prev.captured,
				last: prev.last,
				history: state.history.slice(0, -1),
				selected: null
			};
		}
		case "reset":
			if (sameStart(state)) return {
				...state,
				selected: null,
				flipped: state.flipped
			};
			return {
				board: startingBoard(),
				captured: [],
				last: null,
				history: pushHistory(state),
				selected: null,
				flipped: state.flipped
			};
		case "flip": return {
			...state,
			flipped: !state.flipped
		};
		case "hydrate": return action.state;
		default: return state;
	}
}
function sameStart(state) {
	if (state.captured.length || state.last) return false;
	const start = startingBoard();
	return state.board.every((piece, i) => {
		const other = start[i];
		if (!piece || !other) return piece === other;
		return piece.color === other.color && piece.kind === other.kind;
	});
}
function fileOf(index) {
	return index % 8;
}
function rankOf(index) {
	return 8 - Math.floor(index / 8);
}
function coordOf(index) {
	return `${"abcdefgh"[fileOf(index)]}${rankOf(index)}`;
}
function isLightSquare(index) {
	return (fileOf(index) + rankOf(index)) % 2 === 0;
}
var PIECE_LABEL = {
	k: {
		w: "белый король",
		b: "чёрный король"
	},
	q: {
		w: "белый ферзь",
		b: "чёрный ферзь"
	},
	r: {
		w: "белая ладья",
		b: "чёрная ладья"
	},
	b: {
		w: "белый слон",
		b: "чёрный слон"
	},
	n: {
		w: "белый конь",
		b: "чёрный конь"
	},
	p: {
		w: "белая пешка",
		b: "чёрная пешка"
	}
};
function pieceLabel(piece) {
	return PIECE_LABEL[piece.kind][piece.color];
}
function pieceSrc(piece) {
	return `/pieces/${piece.color}${piece.kind.toUpperCase()}.svg`;
}
var SAVE_KEY = "free-chess-v1";
function isPiece(value) {
	if (!value || typeof value !== "object") return false;
	const piece = value;
	return (piece.color === "w" || piece.color === "b") && KINDS.has(piece.kind) && typeof piece.id === "string";
}
function isBoard(value) {
	if (!Array.isArray(value) || value.length !== 64) return false;
	return value.every((cell) => cell === null || isPiece(cell));
}
function loadState() {
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return null;
		const data = JSON.parse(raw);
		if (!isBoard(data.board) || !Array.isArray(data.captured) || !data.captured.every(isPiece)) return null;
		const last = Array.isArray(data.last) && data.last.length === 2 && Number.isInteger(data.last[0]) && Number.isInteger(data.last[1]) ? data.last : null;
		const history = Array.isArray(data.history) ? data.history.filter((snap) => !!snap && isBoard(snap.board) && Array.isArray(snap.captured) && snap.captured.every(isPiece)) : [];
		return {
			board: data.board,
			captured: data.captured,
			last,
			history: history.slice(-80),
			selected: null,
			flipped: data.flipped === true
		};
	} catch {
		return null;
	}
}
function saveState(state) {
	const payload = {
		...state,
		selected: null
	};
	localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
}
var ctx = null;
function knock() {
	const AudioCtx = window.AudioContext || window.webkitAudioContext;
	if (!AudioCtx) return;
	ctx ??= new AudioCtx();
	if (ctx.state === "suspended") ctx.resume();
	const now = ctx.currentTime;
	const osc = ctx.createOscillator();
	const filter = ctx.createBiquadFilter();
	const gain = ctx.createGain();
	osc.type = "triangle";
	osc.frequency.setValueAtTime(210, now);
	osc.frequency.exponentialRampToValueAtTime(90, now + .07);
	filter.type = "lowpass";
	filter.frequency.setValueAtTime(900, now);
	gain.gain.setValueAtTime(1e-4, now);
	gain.gain.exponentialRampToValueAtTime(.06, now + .008);
	gain.gain.exponentialRampToValueAtTime(1e-4, now + .09);
	osc.connect(filter);
	filter.connect(gain);
	gain.connect(ctx.destination);
	osc.start(now);
	osc.stop(now + .1);
}
var SIDE_NAME = {
	w: "Белые",
	b: "Чёрные"
};
function ChessTable() {
	const [state, dispatch] = (0, import_react.useReducer)(reducer, void 0, initialState);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const [dragFrom, setDragFrom] = (0, import_react.useState)(null);
	const [dragMoved, setDragMoved] = (0, import_react.useState)(false);
	const [hover, setHover] = (0, import_react.useState)(null);
	const [landId, setLandId] = (0, import_react.useState)(null);
	const boardRef = (0, import_react.useRef)(null);
	const ghostRef = (0, import_react.useRef)(null);
	const dragRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const saved = loadState();
		if (saved) dispatch({
			type: "hydrate",
			state: saved
		});
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		saveState(state);
	}, [ready, state]);
	function placeGhost(clientX, clientY) {
		const ghost = ghostRef.current;
		const board = boardRef.current;
		if (!ghost || !board) return;
		const size = board.getBoundingClientRect().width / 8;
		ghost.style.width = `${size}px`;
		ghost.style.height = `${size}px`;
		ghost.style.transform = `translate(${clientX - size / 2}px, ${clientY - size / 2}px)`;
	}
	function squareFromPoint(clientX, clientY) {
		const board = boardRef.current;
		if (!board) return null;
		const rect = board.getBoundingClientRect();
		const x = clientX - rect.left;
		const y = clientY - rect.top;
		if (x < 0 || y < 0 || x >= rect.width || y >= rect.height) return null;
		const col = Math.min(7, Math.floor(x / rect.width * 8));
		const visual = Math.min(7, Math.floor(y / rect.height * 8)) * 8 + col;
		return state.flipped ? 63 - visual : visual;
	}
	function move(from, to) {
		const piece = state.board[from];
		if (!piece || from === to) {
			dispatch({
				type: "select",
				index: null
			});
			return;
		}
		dispatch({
			type: "move",
			from,
			to
		});
		setLandId(piece.id);
		knock();
	}
	function tap(index) {
		const { selected, board } = state;
		if (selected == null) {
			if (board[index]) dispatch({
				type: "select",
				index
			});
			return;
		}
		if (selected === index) {
			dispatch({
				type: "select",
				index: null
			});
			return;
		}
		move(selected, index);
	}
	function onPointerDown(event, index) {
		if (event.button !== 0) return;
		if (!state.board[index]) {
			if (state.selected != null) move(state.selected, index);
			return;
		}
		event.preventDefault();
		dragRef.current = {
			from: index,
			x: event.clientX,
			y: event.clientY,
			moved: false,
			pointerId: event.pointerId
		};
		setDragFrom(index);
		setDragMoved(false);
		event.currentTarget.setPointerCapture(event.pointerId);
	}
	function onPointerMove(event) {
		const drag = dragRef.current;
		if (!drag || event.pointerId !== drag.pointerId) return;
		const dx = event.clientX - drag.x;
		const dy = event.clientY - drag.y;
		if (!drag.moved && dx * dx + dy * dy > 36) {
			drag.moved = true;
			setDragMoved(true);
		}
		if (drag.moved) placeGhost(event.clientX, event.clientY);
		const next = drag.moved ? squareFromPoint(event.clientX, event.clientY) : null;
		setHover((prev) => prev === next ? prev : next);
	}
	function endDrag(event) {
		const drag = dragRef.current;
		if (!drag || event.pointerId !== drag.pointerId) return;
		const moved = drag.moved;
		const from = drag.from;
		dragRef.current = null;
		setDragFrom(null);
		setDragMoved(false);
		setHover(null);
		if (!moved) {
			tap(from);
			return;
		}
		const to = squareFromPoint(event.clientX, event.clientY);
		if (to == null || to === from) {
			dispatch({
				type: "select",
				index: from
			});
			return;
		}
		move(from, to);
	}
	function onKeyDown(event) {
		const key = event.key;
		if (key === "Escape") {
			dispatch({
				type: "select",
				index: null
			});
			setCursor(null);
			return;
		}
		if (key === "ArrowLeft" || key === "ArrowRight" || key === "ArrowUp" || key === "ArrowDown") {
			event.preventDefault();
			const dx = key === "ArrowLeft" ? -1 : key === "ArrowRight" ? 1 : 0;
			const dy = key === "ArrowUp" ? -1 : key === "ArrowDown" ? 1 : 0;
			setCursor((current) => nudge(current ?? (state.flipped ? 63 : 0), dx, dy, state.flipped));
			return;
		}
		if (key === "Enter" || key === " ") {
			event.preventDefault();
			const index = cursor ?? (state.flipped ? 63 : 0);
			setCursor(index);
			tap(index);
		}
	}
	const top = state.flipped ? "w" : "b";
	const bottom = state.flipped ? "b" : "w";
	const selectedPiece = state.selected == null ? null : state.board[state.selected];
	const draggingPiece = dragFrom == null ? null : state.board[dragFrom];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col items-center justify-center px-3 py-4 sm:px-6 sm:py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "play-stage flex flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "flex items-end justify-between gap-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-xl font-semibold tracking-tight text-fg sm:text-2xl",
						children: "Свободные шахматы"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Любая фигура, любая клетка, можно рубить своих"
					})] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideRow, {
					color: top,
					captured: state.captured
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg bg-frame p-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: boardRef,
						className: "board grid grid-cols-8 overflow-hidden rounded-sm outline-none",
						role: "application",
						"aria-label": "Шахматная доска без правил",
						tabIndex: 0,
						onPointerMove,
						onPointerUp: endDrag,
						onPointerCancel: endDrag,
						onKeyDown,
						onContextMenu: (event) => event.preventDefault(),
						children: Array.from({ length: 64 }, (_, visual) => {
							const index = state.flipped ? 63 - visual : visual;
							const piece = state.board[index];
							const light = isLightSquare(index);
							const marked = state.selected === index || hover === index || state.last?.[0] === index || state.last?.[1] === index;
							const showRank = visual % 8 === 0;
							const showFile = visual >= 56;
							const coordClass = light ? "text-board-dark" : "text-board-light";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: "button",
								"aria-label": squareLabel(index, state),
								onPointerDown: (event) => onPointerDown(event, index),
								className: "relative flex aspect-square items-center justify-center " + (marked ? light ? "bg-mark-light" : "bg-mark-dark" : light ? "bg-board-light" : "bg-board-dark") + (cursor === index ? " ring-2 ring-inset ring-fg" : ""),
								children: [
									showRank && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `pointer-events-none absolute top-0.5 left-1 text-xs font-semibold leading-none ${coordClass}`,
										children: rankOf(index)
									}),
									showFile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `pointer-events-none absolute right-1 bottom-0.5 text-xs font-semibold leading-none ${coordClass}`,
										children: "abcdefgh"[fileOf(index)]
									}),
									piece && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: pieceSrc(piece),
										alt: "",
										draggable: false,
										className: "piece " + (dragFrom === index && dragMoved ? "opacity-25 " : "") + (landId === piece.id && dragFrom !== index ? "piece-land" : "")
									})
								]
							}, visual);
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideRow, {
					color: bottom,
					captured: state.captured
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-h-5 text-center text-sm text-muted",
					"aria-live": "polite",
					children: selectedPiece ? `Выбрано: ${pieceLabel(selectedPiece)}. Куда угодно — или ещё раз, чтобы отпустить.` : "Перетащи фигуру или нажми её, потом клетку."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Назад",
							disabled: state.history.length === 0,
							onClick: () => {
								dispatch({ type: "undo" });
								knock();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {
								"aria-hidden": "true",
								className: "size-4"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Заново",
							onClick: () => {
								dispatch({ type: "reset" });
								knock();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								"aria-hidden": "true",
								className: "size-4"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Повернуть",
							onClick: () => dispatch({ type: "flip" }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownUp, {
								"aria-hidden": "true",
								className: "size-4"
							})
						})
					]
				})
			]
		}), draggingPiece && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			ref: ghostRef,
			src: pieceSrc(draggingPiece),
			alt: "",
			className: "drag-ghost",
			style: { opacity: dragMoved ? 1 : 0 }
		})]
	});
}
function squareLabel(index, state) {
	const piece = state.board[index];
	const coord = coordOf(index);
	return piece ? `${coord}, ${pieceLabel(piece)}` : coord;
}
function SideRow({ color, captured }) {
	const mine = captured.filter((piece) => piece.color === color);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-8 items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "w-16 shrink-0 text-sm font-semibold text-fg",
			children: SIDE_NAME[color]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-w-0 flex-1 flex-wrap items-center gap-0.5",
			children: mine.map((piece) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: pieceSrc(piece),
				alt: pieceLabel(piece),
				draggable: false,
				className: "size-5"
			}, piece.id))
		})]
	});
}
function ToolbarButton({ label, disabled, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled,
		onClick,
		className: "inline-flex h-11 items-center justify-center gap-1.5 rounded-md border border-border bg-surface px-2 text-sm font-semibold text-fg transition-opacity duration-150 ease-out hover:opacity-90 disabled:opacity-40",
		children: [children, label]
	});
}
function nudge(current, dx, dy, flipped) {
	const visual = flipped ? 63 - current : current;
	const col = Math.max(0, Math.min(7, visual % 8 + dx));
	const next = Math.max(0, Math.min(7, Math.floor(visual / 8) + dy)) * 8 + col;
	return flipped ? 63 - next : next;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChessTable, {});
}
//#endregion
export { Home as component };
