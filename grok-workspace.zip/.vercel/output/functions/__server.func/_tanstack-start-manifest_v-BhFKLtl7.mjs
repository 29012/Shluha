//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BhFKLtl7.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DN6HVURo.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DN6HVURo.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DeCB8p-S.js"]
	}
} });
//#endregion
export { tsrStartManifest };
