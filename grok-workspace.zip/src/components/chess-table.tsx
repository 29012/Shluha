import { useEffect, useReducer, useRef, useState, type KeyboardEvent, type PointerEvent, type ReactNode } from "react";
import { ArrowDownUp, RotateCcw, Undo2 } from "lucide-react";
import {
  coordOf,
  fileOf,
  initialState,
  isLightSquare,
  loadState,
  pieceLabel,
  pieceSrc,
  rankOf,
  reducer,
  saveState,
  type Color,
  type GameState,
} from "@/lib/chess";
import { knock } from "@/lib/knock";

const SIDE_NAME: Record<Color, string> = { w: "Белые", b: "Чёрные" };

export function ChessTable() {
  const [state, dispatch] = useReducer(reducer, undefined, initialState);
  const [ready, setReady] = useState(false);
  const [cursor, setCursor] = useState<number | null>(null);
  const [dragFrom, setDragFrom] = useState<number | null>(null);
  const [dragMoved, setDragMoved] = useState(false);
  const [hover, setHover] = useState<number | null>(null);
  const [landId, setLandId] = useState<string | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const ghostRef = useRef<HTMLImageElement>(null);
  const dragRef = useRef<{
    from: number;
    x: number;
    y: number;
    moved: boolean;
    pointerId: number;
  } | null>(null);

  useEffect(() => {
    const saved = loadState();
    if (saved) dispatch({ type: "hydrate", state: saved });
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    saveState(state);
  }, [ready, state]);

  function placeGhost(clientX: number, clientY: number) {
    const ghost = ghostRef.current;
    const board = boardRef.current;
    if (!ghost || !board) return;
    const size = board.getBoundingClientRect().width / 8;
    ghost.style.width = `${size}px`;
    ghost.style.height = `${size}px`;
    ghost.style.transform = `translate(${clientX - size / 2}px, ${clientY - size / 2}px)`;
  }

  function squareFromPoint(clientX: number, clientY: number): number | null {
    const board = boardRef.current;
    if (!board) return null;
    const rect = board.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    if (x < 0 || y < 0 || x >= rect.width || y >= rect.height) return null;
    const col = Math.min(7, Math.floor((x / rect.width) * 8));
    const row = Math.min(7, Math.floor((y / rect.height) * 8));
    const visual = row * 8 + col;
    return state.flipped ? 63 - visual : visual;
  }

  function move(from: number, to: number) {
    const piece = state.board[from];
    if (!piece || from === to) {
      dispatch({ type: "select", index: null });
      return;
    }
    dispatch({ type: "move", from, to });
    setLandId(piece.id);
    knock();
  }

  function tap(index: number) {
    const { selected, board } = state;
    if (selected == null) {
      if (board[index]) dispatch({ type: "select", index });
      return;
    }
    if (selected === index) {
      dispatch({ type: "select", index: null });
      return;
    }
    move(selected, index);
  }

  function onPointerDown(event: PointerEvent<HTMLDivElement>, index: number) {
    if (event.button !== 0) return;
    const piece = state.board[index];
    if (!piece) {
      if (state.selected != null) move(state.selected, index);
      return;
    }
    event.preventDefault();
    dragRef.current = {
      from: index,
      x: event.clientX,
      y: event.clientY,
      moved: false,
      pointerId: event.pointerId,
    };
    setDragFrom(index);
    setDragMoved(false);
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function onPointerMove(event: PointerEvent<HTMLDivElement>) {
    const drag = dragRef.current;
    if (!drag || event.pointerId !== drag.pointerId) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    if (!drag.moved && dx * dx + dy * dy > 36) {
      drag.moved = true;
      setDragMoved(true);
    }
    if (drag.moved) placeGhost(event.clientX, event.clientY);
    const next = drag.moved ? squareFromPoint(event.clientX, event.clientY) : null;
    setHover((prev) => (prev === next ? prev : next));
  }

  function endDrag(event: PointerEvent<HTMLDivElement>) {
    const drag = dragRef.current;
    if (!drag || event.pointerId !== drag.pointerId) return;
    const moved = drag.moved;
    const from = drag.from;
    dragRef.current = null;
    setDragFrom(null);
    setDragMoved(false);
    setHover(null);
    if (!moved) {
      tap(from);
      return;
    }
    const to = squareFromPoint(event.clientX, event.clientY);
    if (to == null || to === from) {
      dispatch({ type: "select", index: from });
      return;
    }
    move(from, to);
  }

  function onKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    const key = event.key;
    if (key === "Escape") {
      dispatch({ type: "select", index: null });
      setCursor(null);
      return;
    }
    if (key === "ArrowLeft" || key === "ArrowRight" || key === "ArrowUp" || key === "ArrowDown") {
      event.preventDefault();
      const dx = key === "ArrowLeft" ? -1 : key === "ArrowRight" ? 1 : 0;
      const dy = key === "ArrowUp" ? -1 : key === "ArrowDown" ? 1 : 0;
      setCursor((current) => nudge(current ?? (state.flipped ? 63 : 0), dx, dy, state.flipped));
      return;
    }
    if (key === "Enter" || key === " ") {
      event.preventDefault();
      const index = cursor ?? (state.flipped ? 63 : 0);
      setCursor(index);
      tap(index);
    }
  }

  const top: Color = state.flipped ? "w" : "b";
  const bottom: Color = state.flipped ? "b" : "w";
  const selectedPiece = state.selected == null ? null : state.board[state.selected];
  const draggingPiece = dragFrom == null ? null : state.board[dragFrom];

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col items-center justify-center px-3 py-4 sm:px-6 sm:py-8">
      <div className="play-stage flex flex-col gap-3">
        <header className="flex items-end justify-between gap-3">
          <div>
            <h1 className="font-display text-xl font-semibold tracking-tight text-fg sm:text-2xl">
              Свободные шахматы
            </h1>
            <p className="mt-1 text-sm text-muted">Любая фигура, любая клетка, можно рубить своих</p>
          </div>
        </header>

        <SideRow color={top} captured={state.captured} />

        <div className="rounded-lg bg-frame p-2">
          <div
            ref={boardRef}
            className="board grid grid-cols-8 overflow-hidden rounded-sm outline-none"
            role="application"
            aria-label="Шахматная доска без правил"
            tabIndex={0}
            onPointerMove={onPointerMove}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
            onKeyDown={onKeyDown}
            onContextMenu={(event) => event.preventDefault()}
          >
            {Array.from({ length: 64 }, (_, visual) => {
              const index = state.flipped ? 63 - visual : visual;
              const piece = state.board[index];
              const light = isLightSquare(index);
              const marked =
                state.selected === index ||
                hover === index ||
                state.last?.[0] === index ||
                state.last?.[1] === index;
              const showRank = visual % 8 === 0;
              const showFile = visual >= 56;
              const coordClass = light ? "text-board-dark" : "text-board-light";
              return (
                <div
                  key={visual}
                  role="button"
                  aria-label={squareLabel(index, state)}
                  onPointerDown={(event) => onPointerDown(event, index)}
                  className={
                    "relative flex aspect-square items-center justify-center " +
                    (marked
                      ? light
                        ? "bg-mark-light"
                        : "bg-mark-dark"
                      : light
                        ? "bg-board-light"
                        : "bg-board-dark") +
                    (cursor === index ? " ring-2 ring-inset ring-fg" : "")
                  }
                >
                  {showRank && (
                    <span
                      className={`pointer-events-none absolute top-0.5 left-1 text-xs font-semibold leading-none ${coordClass}`}
                    >
                      {rankOf(index)}
                    </span>
                  )}
                  {showFile && (
                    <span
                      className={`pointer-events-none absolute right-1 bottom-0.5 text-xs font-semibold leading-none ${coordClass}`}
                    >
                      {"abcdefgh"[fileOf(index)]}
                    </span>
                  )}
                  {piece && (
                    <img
                      src={pieceSrc(piece)}
                      alt=""
                      draggable={false}
                      className={
                        "piece " +
                        (dragFrom === index && dragMoved ? "opacity-25 " : "") +
                        (landId === piece.id && dragFrom !== index ? "piece-land" : "")
                      }
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <SideRow color={bottom} captured={state.captured} />

        <p className="min-h-5 text-center text-sm text-muted" aria-live="polite">
          {selectedPiece
            ? `Выбрано: ${pieceLabel(selectedPiece)}. Куда угодно — или ещё раз, чтобы отпустить.`
            : "Перетащи фигуру или нажми её, потом клетку."}
        </p>

        <div className="grid grid-cols-3 gap-2">
          <ToolbarButton
            label="Назад"
            disabled={state.history.length === 0}
            onClick={() => {
              dispatch({ type: "undo" });
              knock();
            }}
          >
            <Undo2 aria-hidden="true" className="size-4" />
          </ToolbarButton>
          <ToolbarButton
            label="Заново"
            onClick={() => {
              dispatch({ type: "reset" });
              knock();
            }}
          >
            <RotateCcw aria-hidden="true" className="size-4" />
          </ToolbarButton>
          <ToolbarButton label="Повернуть" onClick={() => dispatch({ type: "flip" })}>
            <ArrowDownUp aria-hidden="true" className="size-4" />
          </ToolbarButton>
        </div>
      </div>

      {draggingPiece && (
        <img
          ref={ghostRef}
          src={pieceSrc(draggingPiece)}
          alt=""
          className="drag-ghost"
          style={{ opacity: dragMoved ? 1 : 0 }}
        />
      )}
    </main>
  );
}

function squareLabel(index: number, state: GameState): string {
  const piece = state.board[index];
  const coord = coordOf(index);
  return piece ? `${coord}, ${pieceLabel(piece)}` : coord;
}

function SideRow({ color, captured }: { color: Color; captured: GameState["captured"] }) {
  const mine = captured.filter((piece) => piece.color === color);
  return (
    <div className="flex min-h-8 items-center gap-3">
      <span className="w-16 shrink-0 text-sm font-semibold text-fg">{SIDE_NAME[color]}</span>
      <div className="flex min-w-0 flex-1 flex-wrap items-center gap-0.5">
        {mine.map((piece) => (
          <img
            key={piece.id}
            src={pieceSrc(piece)}
            alt={pieceLabel(piece)}
            draggable={false}
            className="size-5"
          />
        ))}
      </div>
    </div>
  );
}

function ToolbarButton({
  label,
  disabled,
  onClick,
  children,
}: {
  label: string;
  disabled?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className="inline-flex h-11 items-center justify-center gap-1.5 rounded-md border border-border bg-surface px-2 text-sm font-semibold text-fg transition-opacity duration-150 ease-out hover:opacity-90 disabled:opacity-40"
    >
      {children}
      {label}
    </button>
  );
}

function nudge(current: number, dx: number, dy: number, flipped: boolean): number {
  const visual = flipped ? 63 - current : current;
  const col = Math.max(0, Math.min(7, (visual % 8) + dx));
  const row = Math.max(0, Math.min(7, Math.floor(visual / 8) + dy));
  const next = row * 8 + col;
  return flipped ? 63 - next : next;
}
