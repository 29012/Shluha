export type Color = "w" | "b";
export type Kind = "k" | "q" | "r" | "b" | "n" | "p";

export type Piece = {
  id: string;
  color: Color;
  kind: Kind;
};

export type Square = Piece | null;

export type Snapshot = {
  board: Square[];
  captured: Piece[];
  last: [number, number] | null;
};

export type GameState = {
  board: Square[];
  captured: Piece[];
  last: [number, number] | null;
  history: Snapshot[];
  selected: number | null;
  flipped: boolean;
};

const KINDS = new Set<Kind>(["k", "q", "r", "b", "n", "p"]);

const START_ROWS = [
  "rnbqkbnr",
  "pppppppp",
  "8",
  "8",
  "8",
  "8",
  "PPPPPPPP",
  "RNBQKBNR",
];

export function startingBoard(): Square[] {
  const board: Square[] = [];
  for (const row of START_ROWS) {
    for (const ch of row) {
      if (ch === "8") {
        for (let i = 0; i < 8; i++) board.push(null);
        continue;
      }
      const color: Color = ch === ch.toUpperCase() ? "w" : "b";
      const kind = ch.toLowerCase() as Kind;
      board.push({
        id: `${color}${kind}-${board.length}`,
        color,
        kind,
      });
    }
  }
  return board;
}

export function initialState(): GameState {
  return {
    board: startingBoard(),
    captured: [],
    last: null,
    history: [],
    selected: null,
    flipped: false,
  };
}

export type Action =
  | { type: "move"; from: number; to: number }
  | { type: "select"; index: number | null }
  | { type: "undo" }
  | { type: "reset" }
  | { type: "flip" }
  | { type: "hydrate"; state: GameState };

function pushHistory(state: GameState): Snapshot[] {
  const snap: Snapshot = {
    board: state.board,
    captured: state.captured,
    last: state.last,
  };
  const next = state.history.concat(snap);
  return next.length > 80 ? next.slice(next.length - 80) : next;
}

export function reducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case "select":
      return { ...state, selected: action.index };
    case "move": {
      const { from, to } = action;
      const piece = state.board[from];
      if (!piece || from === to || to < 0 || to > 63) return state;
      const board = state.board.slice();
      const victim = board[to];
      board[from] = null;
      board[to] = piece;
      return {
        ...state,
        board,
        captured: victim ? state.captured.concat(victim) : state.captured,
        last: [from, to],
        history: pushHistory(state),
        selected: null,
      };
    }
    case "undo": {
      const prev = state.history[state.history.length - 1];
      if (!prev) return state;
      return {
        ...state,
        board: prev.board,
        captured: prev.captured,
        last: prev.last,
        history: state.history.slice(0, -1),
        selected: null,
      };
    }
    case "reset": {
      if (sameStart(state)) return { ...state, selected: null, flipped: state.flipped };
      return {
        board: startingBoard(),
        captured: [],
        last: null,
        history: pushHistory(state),
        selected: null,
        flipped: state.flipped,
      };
    }
    case "flip":
      return { ...state, flipped: !state.flipped };
    case "hydrate":
      return action.state;
    default:
      return state;
  }
}

function sameStart(state: GameState): boolean {
  if (state.captured.length || state.last) return false;
  const start = startingBoard();
  return state.board.every((piece, i) => {
    const other = start[i];
    if (!piece || !other) return piece === other;
    return piece.color === other.color && piece.kind === other.kind;
  });
}

export function fileOf(index: number): number {
  return index % 8;
}

export function rankOf(index: number): number {
  return 8 - Math.floor(index / 8);
}

export function coordOf(index: number): string {
  return `${"abcdefgh"[fileOf(index)]}${rankOf(index)}`;
}

export function isLightSquare(index: number): boolean {
  return (fileOf(index) + rankOf(index)) % 2 === 0;
}

const PIECE_LABEL: Record<Kind, Record<Color, string>> = {
  k: { w: "белый король", b: "чёрный король" },
  q: { w: "белый ферзь", b: "чёрный ферзь" },
  r: { w: "белая ладья", b: "чёрная ладья" },
  b: { w: "белый слон", b: "чёрный слон" },
  n: { w: "белый конь", b: "чёрный конь" },
  p: { w: "белая пешка", b: "чёрная пешка" },
};

export function pieceLabel(piece: Piece): string {
  return PIECE_LABEL[piece.kind][piece.color];
}

export function pieceSrc(piece: Piece): string {
  return `/pieces/${piece.color}${piece.kind.toUpperCase()}.svg`;
}

const SAVE_KEY = "free-chess-v1";

function isPiece(value: unknown): value is Piece {
  if (!value || typeof value !== "object") return false;
  const piece = value as Piece;
  return (
    (piece.color === "w" || piece.color === "b") &&
    KINDS.has(piece.kind) &&
    typeof piece.id === "string"
  );
}

function isBoard(value: unknown): value is Square[] {
  if (!Array.isArray(value) || value.length !== 64) return false;
  return value.every((cell) => cell === null || isPiece(cell));
}

export function loadState(): GameState | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<GameState>;
    if (!isBoard(data.board) || !Array.isArray(data.captured) || !data.captured.every(isPiece)) {
      return null;
    }
    const last =
      Array.isArray(data.last) &&
      data.last.length === 2 &&
      Number.isInteger(data.last[0]) &&
      Number.isInteger(data.last[1])
        ? (data.last as [number, number])
        : null;
    const history = Array.isArray(data.history)
      ? data.history.filter(
          (snap): snap is Snapshot =>
            !!snap &&
            isBoard(snap.board) &&
            Array.isArray(snap.captured) &&
            snap.captured.every(isPiece),
        )
      : [];
    return {
      board: data.board,
      captured: data.captured,
      last,
      history: history.slice(-80),
      selected: null,
      flipped: data.flipped === true,
    };
  } catch {
    return null;
  }
}

export function saveState(state: GameState) {
  const payload: GameState = { ...state, selected: null };
  localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
}
