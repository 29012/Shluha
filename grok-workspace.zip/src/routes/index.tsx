import { createFileRoute } from "@tanstack/react-router";
import { ChessTable } from "@/components/chess-table";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ChessTable />;
}
